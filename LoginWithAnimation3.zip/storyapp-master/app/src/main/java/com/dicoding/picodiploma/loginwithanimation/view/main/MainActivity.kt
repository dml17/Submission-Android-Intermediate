package com.dicoding.picodiploma.loginwithanimation.view.main

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.WindowInsets
import android.view.WindowManager
import androidx.activity.viewModels
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.viewModelScope
import com.dicoding.picodiploma.loginwithanimation.R
import com.dicoding.picodiploma.loginwithanimation.data.retrofit.Retrofit
import com.dicoding.picodiploma.loginwithanimation.databinding.ActivityMainBinding
import com.dicoding.picodiploma.loginwithanimation.view.ViewModelFactory
import com.dicoding.picodiploma.loginwithanimation.view.detail.DetailActivity
import com.dicoding.picodiploma.loginwithanimation.view.newstory.NewStoryActivity
import com.dicoding.picodiploma.loginwithanimation.view.welcome.WelcomeActivity
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity(),StoryClickListener {
    private val viewModel by viewModels<MainViewModel> {
        ViewModelFactory.getInstance(this)
    }
    private lateinit var binding: ActivityMainBinding
    private var token : String? = null
    private val apiService = Retrofit.getRetrofit()
    private val storyRepository = StoryRepository(apiService)
    private lateinit var storyAdapter: StoryAdapter

    @RequiresApi(Build.VERSION_CODES.R)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        storyAdapter = StoryAdapter()
        viewModel.getSession().observe(this) { user ->
            if (!user.isLogin) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
            }

        }
        setupView()
        viewModel.getSession().observe(this) { user ->
            if (user.isLogin) {
                token = user.token
                showLoading(true)
                viewModel.viewModelScope.launch {
                    try {
                        storyRepository.getStories(
                            token!!,
                            onSuccess = { storyList ->
                                updateStoryList(storyList)
                                showLoading(false)
                            },
                            onError = {
                                showLoading(false)
                            }
                        )
                    } catch (e: Exception) {
                        Log.d("Error", e.message.toString())
                        showLoading(false)
                    }
                }
            }
        }
    binding.floatingActionButton.setOnClickListener{
        val intent = Intent(this, NewStoryActivity::class.java)
        intent.putExtra("token",token)
        startActivity(intent)
    }

    }
    @RequiresApi(Build.VERSION_CODES.R)
    private fun setupView() {
        storyAdapter = StoryAdapter()
        storyAdapter.setStoryClickListener(this)
        binding.rv.adapter = storyAdapter
        @Suppress("DEPRECATION")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.hide(WindowInsets.Type.statusBars())
        } else {
            window.setFlags(
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN
            )
        }
    }
    private fun updateStoryList(storyList: List<ListStoryItem>) {
        storyAdapter.submitList(storyList)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.bottom_nav_menu, menu)
        return super.onCreateOptionsMenu(menu)
    }


    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        showLoading(true)
        when (item.itemId) {
            R.id.logout -> {
                viewModel.logout()
            }

        }
        return super.onOptionsItemSelected(item)
    }

    override fun onStoryClick(story: ListStoryItem) {
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra("storyId", story.id)
        intent.putExtra("token",token)
        startActivity(intent)
    }
    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar.visibility = View.VISIBLE
        } else {
            binding.progressBar.visibility = View.GONE
        }
    }


}


