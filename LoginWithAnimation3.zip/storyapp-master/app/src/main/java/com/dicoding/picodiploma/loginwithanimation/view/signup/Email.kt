package com.dicoding.picodiploma.loginwithanimation.view.signup
data class Email(
    val email: String
)
